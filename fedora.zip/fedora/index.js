const express = require('express');
const session = require('express-session');
const fs = require('fs');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');

const app = express();
const port = 3000;

// ---------- Middleware ----------
app.use(express.static('public'));
app.use('/avatars', express.static('public/avatars'));
app.use('/itemImages', express.static('public/itemImages'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(session({ secret: 'fedora_secret_key', resave: false, saveUninitialized: true }));

// ---------- Helper Functions ----------
const readData = (path) => JSON.parse(fs.readFileSync(path));
const writeData = (path, data) => fs.writeFileSync(path, JSON.stringify(data, null, 2));

// ---------- Multer Uploads ----------
const avatarUpload = multer({ dest: 'public/avatars/' });
const itemUpload = multer({ dest: 'public/itemImages/' });

// ---------- Resold Items (new) ----------
const resoldItemsPath = './data/resoldItems.json';
if (!fs.existsSync(resoldItemsPath)) writeData(resoldItemsPath, []);

// ---------- Routes ----------

// Serve main login page
app.get('/', (req, res) => res.sendFile(__dirname + '/public/login.html'));

// Serve dashboard or other pages as needed
app.get('/dashboard', (req, res) => {
    res.sendFile(__dirname + '/public/dashboard.html');
});

// ---------- Authentication ----------
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const users = readData('./data/users.json');
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
        req.session.user = username;
        user.status = 'green'; // Set online status
        writeData('./data/users.json', users);
        res.json({ success: true });
    } else {
        res.json({ error: 'Invalid username or password' });
    }
});

app.post('/signup', (req, res) => {
    const { username, password } = req.body;
    const users = readData('./data/users.json');
    if (users.find(u => u.username === username)) {
        return res.json({ error: 'Username exists' });
    }
    const newUser = {
        username,
        password,
        bobux: 100, // initial amount
        inventory: [], // empty inventory
        friends: [],
        friendRequests: [],
        followers: [],
        avatar: '/images/placeholder.png',
        isAdmin: username === 'Preston',
        bobuxLastUpdate: Date.now(),
        status: 'offline'
    };
    users.push(newUser);
    writeData('./data/users.json', users);
    req.session.user = username;
    newUser.status = 'green'; // Set online
    writeData('./data/users.json', users);
    res.json({ success: true });
});

// Logout
app.post('/logout', (req, res) => {
    if (req.session.user) {
        const users = readData('./data/users.json');
        const user = users.find(u => u.username === req.session.user);
        if (user) {
            user.status = 'offline';
            writeData('./data/users.json', users);
        }
        req.session.destroy(() => {
            res.json({ success: true });
        });
    } else {
        res.json({ success: false });
    }
});

// ---------- Bobux System ----------
app.get('/getBobux', (req, res) => {
    if (!req.session.user) return res.json({ error: 'Not logged in' });
    const users = readData('./data/users.json');
    const user = users.find(u => u.username === req.session.user);
    const now = Date.now();
    const seconds = Math.floor((now - user.bobuxLastUpdate) / 1000);
    const earned = Math.floor(seconds / 15);
    if (earned > 0) {
        user.bobux += earned;
        user.bobuxLastUpdate = now;
        writeData('./data/users.json', users);
    }
    res.json({ bobux: user.bobux });
});

// ---------- Inventory ----------
app.get('/getInventory', (req, res) => {
    if (!req.session.user) return res.json({ error: 'Not logged in' });
    const users = readData('./data/users.json');
    const user = users.find(u => u.username === req.session.user);
    res.json({ inventory: user.inventory });
});

// ---------- Catalog ----------
app.get('/getCatalog', (req, res) => {
    const items = readData('./data/items.json');
    res.json({ items });
});

// ---------- Buy Item ----------
app.post('/buyItem', (req, res) => {
    const { itemId } = req.body;
    if (!req.session.user) return res.json({ error: 'Not logged in' });
    const users = readData('./data/users.json');
    const items = readData('./data/items.json');
    const user = users.find(u => u.username === req.session.user);
    const item = items.find(i => i.id === itemId);
    if (!item) return res.json({ error: 'Item not found' });
    if (user.bobux < item.price) return res.json({ error: 'Not enough Bobux' });
    // Deduct Bobux
    user.bobux -= item.price;
    // Add item with buyPrice and sellPrice
    const inventoryItem = {
        id: item.id,
        name: item.name,
        buyPrice: item.price,
        sellPrice: Math.floor(item.price * 0.8),
        image: item.image
    };
    user.inventory.push(inventoryItem);
    writeData('./data/users.json', users);
    // Respond with success and updated bobux
    res.json({ success: true, bobux: user.bobux });
});

// ---------- Resell Item ----------
app.post('/resellItem', (req, res) => {
    const { itemId } = req.body;
    if (!req.session.user) return res.json({ error: 'Not logged in' });
    const users = readData('./data/users.json');
    const user = users.find(u => u.username === req.session.user);
    const index = user.inventory.findIndex(i => i.id === itemId);
    if (index === -1) return res.json({ error: 'Item not found in inventory' });
    const item = user.inventory[index];
    // Add sellPrice to user's bobux
    user.bobux += item.sellPrice;
    // Save resold info
    const resoldItems = readData('./data/resoldItems.json');
    resoldItems.push({
        id: item.id,
        name: item.name,
        image: item.image,
        resalePrice: item.sellPrice,
        seller: req.session.user,
        timestamp: Date.now()
    });
    writeData('./data/resoldItems.json', resoldItems);
    // Remove item from inventory
    user.inventory.splice(index, 1);
    writeData('./data/users.json', users);
    // Respond with success and new bobux
    res.json({ success: true, newPrice: item.sellPrice, bobux: user.bobux });
});

// ---------- Create Custom Item ----------
app.post('/createItem', itemUpload.single('itemImage'), (req, res) => {
    if (!req.session.user) return res.json({ error: 'Not logged in' });
    const users = readData('./data/users.json');
    const items = readData('./data/items.json');
    const user = users.find(u => u.username === req.session.user);
    const { id, name, type, price } = req.body;
    const maxPrice = user.isAdmin ? Infinity : 10000;
    if (parseInt(price) > maxPrice) return res.json({ error: 'Price too high' });
    let imageUrl = '/images/placeholder.png';
    if (req.file) imageUrl = `/itemImages/${req.file.filename}`;
    const newItem = { id, name, type, price: parseInt(price), image: imageUrl };
    items.push(newItem);
    writeData('./data/items.json', items);
    res.json({ success: true });
});

// ---------- Admin: Add Bobux ----------
app.post('/adminAddBobux', (req, res) => {
    if (!req.session.user) return res.json({ error: 'Not logged in' });
    const users = readData('./data/users.json');
    const admin = users.find(u => u.username === req.session.user);
    if (!admin.isAdmin) return res.json({ error: 'Not admin' });
    const { username, amount } = req.body;
    const user = users.find(u => u.username === username);
    if (!user) return res.json({ error: 'User not found' });
    user.bobux += parseInt(amount);
    writeData('./data/users.json', users);
    res.json({ success: true, newBalance: user.bobux });
});

// ---------- Search ----------
app.get('/searchCatalog', (req, res) => {
    const query = req.query.q?.toLowerCase() || '';
    let items = readData('./data/items.json');
    if (query) {
        items = items.filter(i => i.name.toLowerCase().includes(query));
    }
    res.json({ items });
});
app.get('/searchUsers', (req, res) => {
    const query = req.query.q?.toLowerCase() || '';
    let users = readData('./data/users.json');
    if (query) {
        users = users.filter(u => u.username.toLowerCase().includes(query));
    }
    res.json({ users });
});

// ---------- User Profile ----------
app.get('/userProfile/:username', (req, res) => {
    const username = req.params.username;
    const users = readData('./data/users.json');
    const user = users.find(u => u.username === username);
    if (!user) return res.json({ error: 'User not found' });
    res.json({
        username: user.username,
        inventory: user.inventory,
        bobux: user.bobux,
        followers: user.followers || [],
        friends: user.friends || [],
        avatar: user.avatar
    });
});

// ---------- Friend Requests ----------
app.post('/sendFriendRequest', (req, res) => {
    if (!req.session.user) return res.json({ error: 'Not logged in' });
    const { targetUser } = req.body;
    const users = readData('./data/users.json');
    const sender = users.find(u => u.username === req.session.user);
    const receiver = users.find(u => u.username === targetUser);
    if (!receiver) return res.json({ error: 'User not found' });
    if (!receiver.friendRequests) receiver.friendRequests = [];
    if (receiver.friendRequests.includes(sender.username))
        return res.json({ error: 'Request already sent' });
    receiver.friendRequests.push(sender.username);
    writeData('./data/users.json', users);
    res.json({ success: true });
});
app.post('/respondFriendRequest', (req, res) => {
    if (!req.session.user) return res.json({ error: 'Not logged in' });
    const { fromUser, accept } = req.body;
    const users = readData('./data/users.json');
    const currentUser = users.find(u => u.username === req.session.user);
    const sender = users.find(u => u.username === fromUser);
    if (!currentUser.friendRequests)
        currentUser.friendRequests = [];
    const index = currentUser.friendRequests.indexOf(fromUser);
    if (index === -1) return res.json({ error: 'Request not found' });
    if (accept) {
        if (!currentUser.friends) currentUser.friends = [];
        if (!sender.friends) sender.friends = [];
        currentUser.friends.push(fromUser);
        sender.friends.push(req.session.user);
    }
    currentUser.friendRequests.splice(index, 1);
    writeData('./data/users.json', users);
    res.json({ success: true });
});

// ---------- Follow User ----------
app.post('/followUser', (req, res) => {
    if (!req.session.user) return res.json({ error: 'Not logged in' });
    const { targetUser } = req.body;
    const users = readData('./data/users.json');
    const user = users.find(u => u.username === req.session.user);
    const target = users.find(u => u.username === targetUser);
    if (!target) return res.json({ error: 'User not found' });
    if (!target.followers) target.followers = [];
    if (target.followers.includes(user.username))
        return res.json({ error: 'Already following' });
    target.followers.push(user.username);
    writeData('./data/users.json', users);
    res.json({ success: true });
});
app.get('/getFollowers/:username', (req, res) => {
    const username = req.params.username;
    const users = readData('./data/users.json');
    const user = users.find(u => u.username === username);
    if (!user) return res.json({ error: 'User not found' });
    res.json({ followers: user.followers || [] });
});

// ---------- Get Friends with Status ----------
app.get('/getFriendsWithStatus', (req, res) => {
    if (!req.session.user) return res.json({ error: 'Not logged in' });
    const users = readData('./data/users.json');
    const user = users.find(u => u.username === req.session.user);
    const friendsWithStatus = (user.friends || []).map(friendUsername => {
        const friend = users.find(u => u.username === friendUsername);
        return {
            username: friend.username,
            status: friend.status || 'offline'
        };
    });
    res.json({ friends: friendsWithStatus });
});

// ---------- Avatar Upload ----------
app.post('/uploadAvatar', avatarUpload.single('avatar'), (req, res) => {
    if (!req.session.user) return res.json({ error: 'Not logged in' });
    const users = readData('./data/users.json');
    const user = users.find(u => u.username === req.session.user);
    user.avatar = `/avatars/${req.file.filename}`;
    writeData('./data/users.json', users);
    res.json({ success: true, url: user.avatar });
});

// ---------- Redeem Code ----------
app.post('/redeemCode', (req, res) => {
    if (!req.session.user) return res.json({ error: 'Not logged in' });
    const { code } = req.body;
    const validCodes = {
        'Roblox': 1000,
        'SuperCode': 500
    };
    if (validCodes[code]) {
        const users = readData('./data/users.json');
        const user = users.find(u => u.username === req.session.user);
        user.bobux += validCodes[code];
        writeData('./data/users.json', users);
        return res.json({ success: true, newBalance: user.bobux });
    } else {
        return res.json({ error: 'Invalid code' });
    }
});

// ---------- Groups System ----------
const groupsFile = './data/groups.json';
if (!fs.existsSync(groupsFile)) writeData(groupsFile, []);

app.post('/createGroup', (req, res) => {
    if (!req.session.user) return res.json({ error: 'Not logged in' });
    const { name } = req.body;
    if (!name) return res.json({ error: 'Group name required' });
    const groups = readData(groupsFile);
    const groupId = 'group_' + Date.now();
    const newGroup = {
        id: groupId,
        name,
        owner: req.session.user,
        members: [req.session.user],
        createdAt: Date.now()
    };
    groups.push(newGroup);
    writeData(groupsFile, groups);
    res.json({ success: true, group: newGroup });
});

app.post('/joinGroup', (req, res) => {
    if (!req.session.user) return res.json({ error: 'Not logged in' });
    const { groupId } = req.body;
    const groups = readData(groupsFile);
    const group = groups.find(g => g.id === groupId);
    if (!group) return res.json({ error: 'Group not found' });
    if (!group.members.includes(req.session.user)) {
        group.members.push(req.session.user);
        writeData(groupsFile, groups);
    }
    res.json({ success: true, group });
});

app.post('/leaveGroup', (req, res) => {
    if (!req.session.user) return res.json({ error: 'Not logged in' });
    const { groupId } = req.body;
    let groups = readData(groupsFile);
    const group = groups.find(g => g.id === groupId);
    if (!group) return res.json({ error: 'Group not found' });
    group.members = group.members.filter(m => m !== req.session.user);
    if (group.owner === req.session.user) {
        groups = groups.filter(g => g.id !== groupId);
    }
    writeData('./data/groups.json', groups);
    res.json({ success: true });
});

app.get('/getGroups', (req, res) => {
    if (!req.session.user) return res.json({ error: 'Not logged in' });
    const groups = readData('./data/groups.json');
    const myGroups = groups.filter(g => g.members.includes(req.session.user));
    res.json({ groups: myGroups });
});

// ---------- Periodic Status Update ----------
app.use((req, res, next) => {
    if (req.session.user) {
        const users = readData('./data/users.json');
        const user = users.find(u => u.username === req.session.user);
        if (user) {
            user.status = 'green';
            writeData('./data/users.json', users);
        }
    }
    next();
});

// ======================= ADD THE DELETE ITEM ENDPOINT =======================
app.post('/deleteItem', (req, res) => {
    if (!req.session.user) return res.json({ success: false, message: 'Not logged in' });
    const { itemId } = req.body;
    const users = readData('./data/users.json');
    const user = users.find(u => u.username === req.session.user);
    if (!user) return res.json({ success: false, message: 'User not found' });
    const itemIndex = user.inventory.findIndex(i => i.id === itemId);
    if (itemIndex === -1) return res.json({ success: false, message: 'Item not found in inventory' });
    // Remove the item
    user.inventory.splice(itemIndex, 1);
    writeData('./data/users.json', users);
    res.json({ success: true });
});

// ---------- Get Resold Items ----------
app.get('/getResoldItems', (req, res) => {
    const resoldItems = readData('./data/resoldItems.json');
    res.json(resoldItems);
});

// ---------- Submit a Resell ----------
app.post('/submitResell', (req, res) => {
    if (!req.session.user) return res.json({ error: 'Not logged in' });
    const { itemId, resalePrice } = req.body;
    const users = readData('./data/users.json');
    const user = users.find(u => u.username === req.session.user);
    const inventoryItem = user.inventory.find(i => i.id === itemId);
    if (!inventoryItem) return res.json({ error: 'Item not found in inventory' });
    // Add item to resold list
    const resoldItems = readData('./data/resoldItems.json');
    resoldItems.push({
        id: inventoryItem.id,
        name: inventoryItem.name,
        image: inventoryItem.image,
        resalePrice: parseInt(resalePrice),
        seller: req.session.user,
        timestamp: Date.now()
    });
    writeData('./data/resoldItems.json', resoldItems);
    res.json({ success: true });
});

// ---------- getBobux handler (already included above) ----------
app.get('/getBobux', (req, res) => {
    if (!req.session.user) return res.json({ error: 'Not logged in' });
    const users = readData('./data/users.json');
    const user = users.find(u => u.username === req.session.user);
    if (!user) return res.json({ error: 'User not found' });
    const now = Date.now();
    const seconds = Math.floor((now - user.bobuxLastUpdate) / 1000);
    const earned = Math.floor(seconds / 15);
    if (earned > 0) {
        user.bobux += earned;
        user.bobuxLastUpdate = now;
        writeData('./data/users.json', users);
    }
    res.json({ bobux: user.bobux });
});

app.listen(port, () => console.log(`Fedora app listening at http://localhost:${port}`));