<script>
// ===================== Core Variables =====================
    let bobuxCount = 0;
    let lastUpdateTime = Date.now();

    // ===================== Bobux System =====================
    function startBobuxTimer() {
        setInterval(() => {
            const now = Date.now();
            const elapsedSeconds = Math.floor((now - lastUpdateTime) / 1000);
            if (elapsedSeconds >= 15) {
                const gained = Math.floor(elapsedSeconds / 15);
                bobuxCount += gained;
                lastUpdateTime = now;
                updateBobuxDisplay();
                notify(`?? Bobux +${gained}!`);
            }
        }, 1000);
}

    function updateBobux() {
        fetch('/getBobux', { credentials: 'include' })
            .then(res => res.json())
            .then(data => {
                if (!data.error) {
                    bobuxCount = data.bobux;
                    updateBobuxDisplay();
                }
            });
}

    function updateBobuxDisplay() {
    const bobuxEl = document.getElementById('bobux');
    if (bobuxEl) bobuxEl.innerText = bobuxCount;
}

    // ===================== Account & Session =====================
    function updateAccountStatus() {
        fetch('/getAccountStatus', { credentials: 'include' })
            .then(res => res.json())
            .then(data => {
                const statusDiv = document.getElementById('accountStatus');
                if (!statusDiv) return;

                if (data.loggedIn) {
                    statusDiv.innerHTML = `Logged in as: <strong>${data.username}</strong> ??`;
                    // Add avatar if not present
                    let avatar = document.getElementById('userAvatar');
                    if (!avatar) {
                        avatar = document.createElement('img');
                        avatar.id = 'userAvatar';
                        avatar.style.width = '32px';
                        avatar.style.height = '32px';
                        avatar.style.borderRadius = '50%';
                        avatar.style.marginLeft = '10px';
                        statusDiv.appendChild(avatar);
                    }
                    avatar.src = data.avatar;
                } else {
                    statusDiv.innerHTML = 'Not logged in ?';
                    // Remove avatar if exists
                    const avatar = document.getElementById('userAvatar');
                    if (avatar) avatar.remove();
                }
            });
}

    // Show login/signup modal
    function showAccountMenu() {
    const menu = document.getElementById('accountMenu');
    if (menu) {
        menu.style.display = (menu.style.display === 'none') ? 'block' : 'none';
    }
    updateAccountStatus();
}

    // Show login/signup forms
    function showLoginSignup() {
    const div = document.getElementById('loginSignup');
    if (div) {
        div.style.display = (div.style.display === 'none') ? 'block' : 'none';
    }
}

    // Logout function
    function logout() {
        fetch('/logout', { credentials: 'include' }).then(() => {
            alert('Logged out');
            updateAccountStatus();
            location.reload();
        });
}

    // Sign-up function
    function signupUser() {
    const username = document.getElementById('signupUsername').value;
    const password = document.getElementById('signupPassword').value;
    fetch('/signup', {
        method: 'POST',
    headers: {'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify({username, password})
    }).then(res => res.json())
        .then(data => {
            if (data.success) {
        alert('Signup success!');
    document.getElementById('loginSignup').style.display = 'none';
    updateAccountStatus();
    location.reload();
            } else {
        alert(data.error);
            }
        });
}

    // ===================== Notifications =====================
    function notify(message) {
    const notif = document.createElement('div');
    notif.className = 'notification';
    notif.innerText = message;
    notif.style.position = 'fixed';
    notif.style.bottom = '20px';
    notif.style.right = '20px';
    notif.style.backgroundColor = '#fff';
    notif.style.padding = '10px 20px';
    notif.style.borderRadius = '10px';
    notif.style.boxShadow = '0 4px 8px rgba(0,0,0,0.3)';
    notif.style.zIndex = 9999;
    document.body.appendChild(notif);
    setTimeout(() => notif.remove(), 4000);
}

// ===================== Friends & Status =====================
setInterval(() => {
        fetch('/getFriends')
            .then(res => res.json())
            .then(data => {
                data.friends.forEach(friend => {
                    notify(`?? Friend online: ${friend}`);
                });
            });
}, 30000);

    // Load friends with status color
    function loadFriendsWithStatus() {
        fetch('/getFriendsWithStatus')
            .then(res => res.json())
            .then(data => {
                const friendsDiv = document.getElementById('friendsList');
                if (!friendsDiv) return;
                friendsDiv.innerHTML = '<h4>Friends:</h4>';
                data.friends.forEach(friend => {
                    let color = 'gray';
                    if (friend.status === 'green') color = 'green';
                    if (friend.status === 'blue') color = 'blue';
                    if (friend.status === 'red') color = 'red';
                    const fDiv = document.createElement('div');
                    fDiv.innerHTML = `<span style="color:${color}">?? ${friend.username}</span>`;
                    friendsDiv.appendChild(fDiv);
                });
            });
}
    setInterval(loadFriendsWithStatus, 30000);
    loadFriendsWithStatus();

    // ===================== Inventory & Catalog =====================
    function loadInventory() {
        fetch('/getInventory', { credentials: 'include' })
            .then(res => res.json())
            .then(data => {
                const grid = document.getElementById('inventoryGrid');
                if (!grid) return;
                grid.innerHTML = '';
                if (data.inventory && data.inventory.length > 0) {
                    data.inventory.forEach(item => {
                        const div = document.createElement('div');
                        div.className = 'item-card';
                        div.innerHTML = `<img src="${item.image || 'images/placeholder.png'}" /><p>${item.name}</p><p>?? ${item.buyPrice}</p><p>Resell for: ?? ${item.sellPrice}</p><button onclick="resellItem('${item.id}')">Resell</button>`;
                        grid.appendChild(div);
                    });
                } else {
                    grid.innerHTML = '<p>You have no items.</p>';
                }
            });
}

    function loadCatalog() {
        fetch('/getCatalog', { credentials: 'include' })
            .then(res => res.json())
            .then(data => {
                const grid = document.getElementById('catalogGrid');
                if (!grid) return;
                grid.innerHTML = '';
                data.items.forEach(item => {
                    const div = document.createElement('div');
                    div.className = 'item-card';
                    div.innerHTML = `
          <img src="images/placeholder.png" />
          <p>${item.name}</p>
          <p>?? ${item.price}</p>
          <button onclick="buyItem('${item.id}')">?? Buy</button>`;
                    grid.appendChild(div);
                });
            });
}

    function buyItem(itemId) {
    if (!localStorage.getItem('fedoraUsername')) {
        alert('Please log in to buy items.');
    return;
    }
    fetch('/buyItem', {
        method: 'POST',
    headers: {'Content-Type': 'application/json' },
    body: JSON.stringify({itemId})
    }).then(res => res.json())
        .then(data => {
            if (data.success) {
        alert('Item purchased!');
    updateBobux();
    loadInventory();
            } else alert(data.error);
        });
}

    function resellItem(itemId) {
    if (!localStorage.getItem('fedoraUsername')) {
        alert('Please log in.');
    return;
    }
    // Call server to process resell
    fetch('/resellItem', {
        method: 'POST',
    headers: {'Content-Type': 'application/json' },
    body: JSON.stringify({itemId})
    }).then(res => res.json())
        .then(data => {
            if (data.success) {
        alert(`Resold for ${data.newPrice} Bobux!`);
    loadInventory();
            } else alert(data.error);
        });
}

    // ===================== Admin & Developer =====================
    function createItem() {
    const id = document.getElementById('itemId').value;
    const name = document.getElementById('itemName').value;
    const type = document.getElementById('itemType').value;
    const price = parseInt(document.getElementById('itemPrice').value);
    fetch('/createItem', {
        method: 'POST',
    headers: {'Content-Type': 'application/json' },
    body: JSON.stringify({id, name, type, price})
    }).then(res => res.json())
        .then(data => {
            if (data.success) alert('Item created!');
    else alert(data.error);
        });
}

    function adminAddBobux() {
    const username = document.getElementById('adminUser').value;
    const amount = parseInt(document.getElementById('adminAmount').value);
    fetch('/adminAddBobux', {
        method: 'POST',
    headers: {'Content-Type': 'application/json' },
    body: JSON.stringify({username, amount})
    }).then(res => res.json())
        .then(data => {
            if (data.success) alert(`Bobux added! New balance: ${data.newBalance}`);
    else alert(data.error);
        });
}

    // ===================== Search & Profiles =====================
    function performSearch() {
    const query = document.getElementById('searchBox')?.value;
    if (!query) return alert('Enter something!');

    // Search Catalog
    fetch(`/searchCatalog?q=${encodeURIComponent(query)}`)
        .then(res => res.json())
        .then(data => {
            const grid = document.getElementById('searchResults');
    if (!grid) return;
    grid.innerHTML = '';
            data.items.forEach(item => {
                const div = document.createElement('div');
    div.className = 'item-card';
    div.innerHTML = `
    <img src="images/placeholder.png" />
    <p>${item.name}</p>
    <p>?? ${item.price}</p>
    <button onclick="buyItem('${item.id}')">?? Buy</button>`;
    grid.appendChild(div);
            });
        });

    // Search Users
    fetch(`/searchUsers?q=${encodeURIComponent(query)}`)
        .then(res => res.json())
        .then(data => {
            const grid = document.getElementById('searchResults');
    if (!grid) return;
            data.users.forEach(user => {
                const div = document.createElement('div');
    div.className = 'item-card';
    div.innerHTML = `
    <p>?? ${user.username}</p>
    <button onclick="viewUserProfile('${user.username}')">?? View Profile</button>
    <button onclick="addFriend('${user.username}')">?? Add Friend</button>`;
    grid.appendChild(div);
            });
        });
}

    function viewUserProfile(username) {
        fetch(`/userProfile/${username}`)
            .then(res => res.json())
            .then(data => {
                if (data.error) return alert(data.error);
                const grid = document.getElementById('searchResults');
                if (!grid) return;
                let rap = 0;
                data.inventory.forEach(i => rap += i.buyPrice || 0);

                let content = `
        <h3>?? ${data.username}'s Profile</h3>
        <p>?? Bobux: ${data.bobux}</p>
        <p>?? RAP: ${rap}</p>
        <h4>Followers:</h4>`;
                if (data.followers?.length) data.followers.forEach(f => { content += `<p>?? ${f}</p>`; });
                else content += `<p>No followers yet.</p>`;

                content += `<h4>Friends:</h4>`;
                if (data.friends?.length) data.friends.forEach(f => { content += `<p>?? ${f}</p>`; });
                else content += `<p>No friends yet.</p>`;

                content += `<h4>Inventory:</h4><div class="grid">`;
                data.inventory.forEach(i => {
                    content += `<div class="item-card"><img src="images/placeholder.png"><p>${i.name}</p><p>?? ${i.buyPrice}</p></div>`;
                });
                content += '</div>';

                // Display profile info in a modal or replace content
                const profileDiv = document.getElementById('searchResults');
                profileDiv.innerHTML = content;
            });
}

    // ---------- Add Friend & Follow ----------
    function addFriend(username) {
        fetch('/addFriend', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username })
        }).then(res => res.json())
            .then(data => {
                if (data.success) notify(`?? ${username} added as friend!`);
                else alert(data.error);
            });
}

    // ===================== Theme & UI =====================
    function openSettings() {
    const panel = document.getElementById('themeSettings');
    if (panel) panel.style.display = (panel.style.display === 'none') ? 'block' : 'none';
}

    function changeTheme(color) {
    switch (color) {
        case 'black':
    document.body.style.background = '#121212';
    document.body.style.color = 'white';
    break;
    case 'purple':
    document.body.style.background = '#800080';
    document.body.style.color = 'white';
    break;
    case 'green':
    document.body.style.background = '#2e8b57';
    document.body.style.color = 'white';
    break;
    case 'blue':
    document.body.style.background = '#1e90ff';
    document.body.style.color = 'white';
    break;
    case 'pink':
    document.body.style.background = '#ff69b4';
    document.body.style.color = 'white';
    break;
    }
}

// ---------- Avatar Upload ----------
document.getElementById('avatarForm')?.addEventListener('submit', e => {
        e.preventDefault();
    const formData = new FormData(e.target);
    fetch('/uploadAvatar', {
        method: 'POST',
    body: formData
    }).then(res => res.json())
        .then(data => {
            if (data.success) {
        document.getElementById('userAvatar').src = data.url;
    notify('?? Avatar uploaded!');
            } else alert(data.error);
        });
});

    // ---------- Friends List with Status ----------
    function loadFriends() {
        fetch('/getFriends')
            .then(res => res.json())
            .then(data => {
                const friendsDiv = document.getElementById('friendsList');
                if (!friendsDiv) return;
                friendsDiv.innerHTML = '<h4>Friends:</h4>';
                data.friends.forEach(friend => {
                    const fDiv = document.createElement('div');
                    fDiv.innerText = `?? ${friend}`;
                    friendsDiv.appendChild(fDiv);
                });
            });
}
    setInterval(loadFriends, 30000);
    loadFriends();

    // ===================== INVENTORY & BUYING & RESALE =====================
    // Load user's inventory (from local storage or server)
    function loadUserInventory() {
    const inventory = JSON.parse(localStorage.getItem('userInventory')) || [];
    const container = document.getElementById('inventoryGrid');
    if (!container) return;
    container.innerHTML = '';
    if (inventory.length === 0) {
        container.innerHTML = '<p>You have no items.</p>';
    return;
    }
    inventory.forEach(item => {
        const div = document.createElement('div');
    div.className = 'item-card';
    div.innerHTML = `
    <img src="${item.image || 'images/placeholder.png'}" />
    <p>${item.name}</p>
    <p>?? ${item.buyPrice}</p>
    <p>Resell for: ?? ${item.sellPrice}</p>
    <button onclick="resellItem('${item.id}')">Resell</button>
    `;
    container.appendChild(div);
    });
}
    // Add item to inventory after purchase
    function addToInventory(item) {
    const inventory = JSON.parse(localStorage.getItem('userInventory')) || [];
    // Optionally, check for duplicates
    inventory.push({
        id: item.id,
    name: item.name,
    image: item.image,
    buyPrice: item.price,
    sellPrice: Math.ceil(item.price * 1.2)
    });
    localStorage.setItem('userInventory', JSON.stringify(inventory));
    loadUserInventory();
}

    // Buy item
    function buyItem(itemId) {
    if (!localStorage.getItem('fedoraUsername')) {
        alert('Please log in to buy items.');
    return;
    }
    // Find item info from catalog
    const item = catalogItems.find(i => i.id === itemId);
    if (!item) return;
    // For demo, deduct bobux, add to inventory
    if (bobuxCount >= item.price) {
        bobuxCount -= item.price;
    updateBobuxDisplay();
    addToInventory(item);
    alert(`Purchased ${item.name} for ${item.price} Bobux!`);
    } else {
        alert('Not enough Bobux.');
    }
}

    // Resell item
    function resellItem(itemId) {
    if (!localStorage.getItem('fedoraUsername')) {
        alert('Please log in.');
    return;
    }
    // Call server to process resell
    fetch('/resellItem', {
        method: 'POST',
    headers: {'Content-Type': 'application/json' },
    body: JSON.stringify({itemId})
    }).then(res => res.json())
        .then(data => {
            if (data.success) {
        alert(`Resold for ${data.newPrice} Bobux!`);
    // Update local inventory
    loadUserInventory();
    // Update Bobux
    bobuxCount += data.newPrice;
    updateBobuxDisplay();
            } else alert(data.error);
        });
}

    // ===================== Resell Logic =====================
    // Resell an item from inventory
    function initiateResell(itemId) {
    // Confirm the user wants to resell
    if (!confirm('Are you sure you want to resell this item?')) return;

    // Find item in inventory
    const inventory = JSON.parse(localStorage.getItem('userInventory')) || [];
    const item = inventory.find(i => i.id === itemId);
    if (!item) {
        alert('Item not found in inventory.');
    return;
    }

    // Send request to server to process resell
    fetch('/submitResell', {
        method: 'POST',
    headers: {'Content-Type': 'application/json' },
    body: JSON.stringify({itemId: item.id, resalePrice: item.sellPrice })
    }).then(res => res.json())
        .then(data => {
            if (data.success) {
        alert(`Item resold for ${item.sellPrice} Bobux!`);
                // Remove item from local inventory
                const index = inventory.findIndex(i => i.id === item.id);
    if (index !== -1) inventory.splice(index, 1);
    localStorage.setItem('userInventory', JSON.stringify(inventory));
    loadUserInventory();
    // Update Bobux
    bobuxCount += item.sellPrice;
    updateBobuxDisplay();
            } else {
        alert('Resell failed: ' + data.error);
            }
        });
}
// Make sure to call this function instead of the previous resell button in your inventory
// Example usage: replace the existing resell button with: <button onclick="initiateResell('${item.id}')">Resell</button>
</script>